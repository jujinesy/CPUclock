// clock.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>

#define WAIT_PERIOD_MS 1000
ULONGLONG ClockRatePerfCt ( unsigned long lnSamplePeriod );

#include <iostream.h>
#include <limits.h>
int main()
{
    printf("Clock = %I64d", ClockRatePerfCt(WAIT_PERIOD_MS));

	return 0;
}

VOID ReadTSC(DWORD *dwLo, DWORD *dwHi) 
{ 
    _asm 
    { 
        _emit    0x0F 
			_emit    0x31 
			
			mov      ecx, dword ptr dwLo 
			mov      dword ptr[ecx], eax 
			
			mov      ecx, dword ptr dwHi 
			mov      dword ptr[ecx], edx 
    } 
} 

ULONGLONG ClockRatePerfCt ( unsigned long lnSamplePeriod )
{
	LARGE_INTEGER PerfCt, OldPerfCt, PerfFreq;
	ULARGE_INTEGER Cycle,OldCycle,ClockHz;
	
	
	QueryPerformanceFrequency(&PerfFreq);
	QueryPerformanceCounter(&OldPerfCt);
	ReadTSC(&OldCycle.u.LowPart, &OldCycle.u.HighPart);
		
	Sleep(lnSamplePeriod);
	
	QueryPerformanceCounter(&PerfCt);
	ReadTSC(&Cycle.u.LowPart, &Cycle.u.HighPart);
		
	ClockHz.QuadPart = (ULONGLONG)(Cycle.QuadPart - OldCycle.QuadPart);
	ClockHz.QuadPart = (ULONGLONG)(ClockHz.QuadPart * PerfFreq.QuadPart) 
						/ (PerfCt.QuadPart - OldPerfCt.QuadPart);
	
	return ClockHz.QuadPart;
}
